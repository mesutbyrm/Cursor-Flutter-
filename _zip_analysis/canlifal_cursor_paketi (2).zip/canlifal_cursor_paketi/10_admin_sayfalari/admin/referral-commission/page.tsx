'use client'

import ReferralCommissionAdmin from '@/components/admin/referral-commission-admin'

export default function AdminReferralCommissionPage() {
  return <ReferralCommissionAdmin />
}
