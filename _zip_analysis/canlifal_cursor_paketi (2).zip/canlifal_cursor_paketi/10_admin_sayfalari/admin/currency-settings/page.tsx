'use client'

import CurrencySettingsAdmin from '@/components/admin/currency-settings-admin'

export default function AdminCurrencySettingsPage() {
  return <CurrencySettingsAdmin />
}
