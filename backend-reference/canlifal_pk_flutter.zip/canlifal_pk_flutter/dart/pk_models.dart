// CanlıFal — PK (Battle) veri modelleri
// Sözleşme: docs/PK_ENTEGRASYON.md
// Backend hem zarflı ({success, data}) hem zarfsız yanıt döndürebilir;
// modeller her iki şekli de karşılar.

enum PkStatus {
  pending,
  starting,
  active,
  paused,
  completed,
  cancelled,
  rejected,
  expired,
  unknown;

  static PkStatus parse(String? v) {
    switch (v) {
      case 'pending':
        return PkStatus.pending;
      case 'starting':
        return PkStatus.starting;
      case 'active':
        return PkStatus.active;
      case 'paused':
        return PkStatus.paused;
      case 'completed':
        return PkStatus.completed;
      case 'cancelled':
        return PkStatus.cancelled;
      case 'rejected':
        return PkStatus.rejected;
      case 'expired':
        return PkStatus.expired;
      default:
        return PkStatus.unknown;
    }
  }

  bool get isLive =>
      this == PkStatus.pending ||
      this == PkStatus.starting ||
      this == PkStatus.active ||
      this == PkStatus.paused;

  bool get isTerminal =>
      this == PkStatus.completed ||
      this == PkStatus.cancelled ||
      this == PkStatus.rejected ||
      this == PkStatus.expired;
}

/// Sunucu kanonik durum geçişleri. İstemci tarafında ön kontrol için.
const Map<PkStatus, List<PkStatus>> kPkTransitions = {
  PkStatus.pending: [
    PkStatus.starting,
    PkStatus.active,
    PkStatus.rejected,
    PkStatus.cancelled,
    PkStatus.expired,
  ],
  PkStatus.starting: [PkStatus.active, PkStatus.cancelled, PkStatus.expired],
  PkStatus.active: [PkStatus.paused, PkStatus.completed],
  PkStatus.paused: [PkStatus.active, PkStatus.completed],
  PkStatus.completed: [],
  PkStatus.cancelled: [],
  PkStatus.rejected: [],
  PkStatus.expired: [],
};

bool canTransition(PkStatus from, PkStatus to) =>
    (kPkTransitions[from] ?? const []).contains(to);

DateTime? _dt(dynamic v) {
  if (v == null) return null;
  final s = v.toString();
  if (s.isEmpty) return null;
  return DateTime.tryParse(s)?.toUtc();
}

String _s(dynamic v) => v?.toString() ?? '';
int _i(dynamic v) => v is int ? v : int.tryParse(v?.toString() ?? '') ?? 0;

class PkUser {
  final String id;
  final String name;
  final String image;

  const PkUser({required this.id, required this.name, required this.image});

  factory PkUser.fromJson(Map<String, dynamic>? j) => PkUser(
        id: _s(j?['id']),
        name: _s(j?['name']).isEmpty ? 'Anonim' : _s(j?['name']),
        image: _s(j?['image']),
      );
}

class PkParticipant {
  final String userId;
  final int side; // 1 veya 2
  final int? seatNumber;
  final bool isCaptain;

  const PkParticipant({
    required this.userId,
    required this.side,
    this.seatNumber,
    this.isCaptain = false,
  });

  factory PkParticipant.fromJson(Map<String, dynamic> j) => PkParticipant(
        userId: _s(j['userId']),
        side: _i(j['side']),
        seatNumber: j['seatNumber'] == null ? null : _i(j['seatNumber']),
        isCaptain: j['isCaptain'] == true,
      );
}

class PkBattle {
  final String id;
  final PkStatus status;

  /// `/api/live/pk` -> room1Id/room2Id
  /// `/api/video-streams/pk` & chat rotası -> stream1Id/stream2Id
  final String side1Id;
  final String side2Id;

  final String user1Id;
  final String user2Id;
  final int score1;
  final int score2;
  final int duration; // saniye
  final String mode; // 1v1, 2v2 ...
  final String scope; // '', 'room', 'room_user'
  final DateTime? createdAt;
  final DateTime? startedAt;
  final DateTime? acceptedAt;
  final DateTime? endsAt;
  final DateTime? endedAt;
  final String winnerId;
  final bool isDraw;
  final PkUser? user1;
  final PkUser? user2;
  final List<PkParticipant> participants;

  /// Sunucu saati — geri sayımlar bununla hesaplanmalı.
  final DateTime? serverNow;

  const PkBattle({
    required this.id,
    required this.status,
    required this.side1Id,
    required this.side2Id,
    required this.user1Id,
    required this.user2Id,
    required this.score1,
    required this.score2,
    required this.duration,
    this.mode = '',
    this.scope = '',
    this.createdAt,
    this.startedAt,
    this.acceptedAt,
    this.endsAt,
    this.endedAt,
    this.winnerId = '',
    this.isDraw = false,
    this.user1,
    this.user2,
    this.participants = const [],
    this.serverNow,
  });

  factory PkBattle.fromJson(Map<String, dynamic> j) {
    return PkBattle(
      id: _s(j['id'] ?? j['battleId']),
      status: PkStatus.parse(_s(j['status'])),
      side1Id: _s(j['room1Id'] ?? j['stream1Id']),
      side2Id: _s(j['room2Id'] ?? j['stream2Id']),
      user1Id: _s(j['user1Id']),
      user2Id: _s(j['user2Id']),
      score1: _i(j['score1']),
      score2: _i(j['score2']),
      duration: j['duration'] == null ? 180 : _i(j['duration']),
      mode: _s(j['mode']),
      scope: _s(j['scope']),
      createdAt: _dt(j['createdAt']),
      startedAt: _dt(j['startedAt']),
      acceptedAt: _dt(j['acceptedAt']),
      endsAt: _dt(j['endsAt'] ?? j['endTime']),
      endedAt: _dt(j['endedAt']),
      winnerId: _s(j['winnerId']),
      isDraw: j['isDraw'] == true,
      user1: j['user1'] is Map
          ? PkUser.fromJson(Map<String, dynamic>.from(j['user1'] as Map))
          : null,
      user2: j['user2'] is Map
          ? PkUser.fromJson(Map<String, dynamic>.from(j['user2'] as Map))
          : null,
      participants: (j['participants'] as List?)
              ?.whereType<Map>()
              .map((e) => PkParticipant.fromJson(Map<String, dynamic>.from(e)))
              .toList() ??
          const [],
      serverNow: _dt(j['serverNow']),
    );
  }

  /// Sunucu saatine göre kalan süre. [clockSkew] = serverNow - cihaz saati.
  Duration remaining({Duration clockSkew = Duration.zero}) {
    final end = endsAt;
    if (end == null) return Duration.zero;
    final now = DateTime.now().toUtc().add(clockSkew);
    final d = end.difference(now);
    return d.isNegative ? Duration.zero : d;
  }

  /// Bekleyen davetin kalan süresi (60 sn zaman aşımı).
  Duration inviteRemaining({Duration clockSkew = Duration.zero}) {
    final c = createdAt;
    if (c == null || status != PkStatus.pending) return Duration.zero;
    final now = DateTime.now().toUtc().add(clockSkew);
    final d = c.add(const Duration(seconds: 60)).difference(now);
    return d.isNegative ? Duration.zero : d;
  }

  bool amIChallenger(String myUserId) => user1Id == myUserId;
  bool amIOpponent(String myUserId) => user2Id == myUserId;
}

class PkCandidate {
  /// Yayın için `streamId`, oda için `roomId`/`id`.
  final String targetId;
  final String userId;
  final String name;
  final String image;
  final String? title;
  final int viewers;

  const PkCandidate({
    required this.targetId,
    required this.userId,
    required this.name,
    required this.image,
    this.title,
    this.viewers = 0,
  });

  factory PkCandidate.fromJson(Map<String, dynamic> j) => PkCandidate(
        targetId: _s(j['streamId'] ?? j['roomId'] ?? j['id']),
        userId: _s(j['userId'] ?? j['ownerId']),
        name: _s(j['name'] ?? j['nameTr'] ?? j['username']),
        image: _s(j['image'] ?? j['icon']),
        title: j['title']?.toString(),
        viewers: _i(j['viewers']),
      );
}

class PkCandidateList {
  final List<PkCandidate> candidates;
  final bool selfBusy;
  final int total;

  const PkCandidateList({
    required this.candidates,
    required this.selfBusy,
    required this.total,
  });

  factory PkCandidateList.fromJson(Map<String, dynamic> j) {
    final list = (j['candidates'] as List?)
            ?.whereType<Map>()
            .map((e) => PkCandidate.fromJson(Map<String, dynamic>.from(e)))
            .toList() ??
        const <PkCandidate>[];
    return PkCandidateList(
      candidates: list,
      selfBusy: j['selfBusy'] == true,
      total: j['total'] == null ? list.length : _i(j['total']),
    );
  }
}

/// SSE `pk` olayı.
class PkEvent {
  final String battleId;
  final String action; // created/started/paused/completed/...
  final String eventType; // PK_STARTING / PK_STARTED / ...
  final PkStatus status;
  final String side1Id;
  final String side2Id;
  final int score1;
  final int score2;
  final int? countdownSec;
  final String challengerName;
  final DateTime? endsAt;
  final DateTime? expiresAt;
  final DateTime? serverNow;
  final List<PkParticipant> participants;
  final Map<String, dynamic> raw;

  const PkEvent({
    required this.battleId,
    required this.action,
    required this.eventType,
    required this.status,
    required this.side1Id,
    required this.side2Id,
    required this.score1,
    required this.score2,
    this.countdownSec,
    this.challengerName = '',
    this.endsAt,
    this.expiresAt,
    this.serverNow,
    this.participants = const [],
    this.raw = const {},
  });

  factory PkEvent.fromJson(Map<String, dynamic> j) => PkEvent(
        battleId: _s(j['battleId'] ?? j['id']),
        action: _s(j['action']),
        eventType: _s(j['eventType']),
        status: PkStatus.parse(_s(j['status'])),
        side1Id: _s(j['room1Id'] ?? j['stream1Id']),
        side2Id: _s(j['room2Id'] ?? j['stream2Id']),
        score1: _i(j['score1']),
        score2: _i(j['score2']),
        countdownSec: j['countdownSec'] == null ? null : _i(j['countdownSec']),
        challengerName: _s(j['challengerName']),
        endsAt: _dt(j['endsAt'] ?? j['endTime']),
        expiresAt: _dt(j['expiresAt']),
        serverNow: _dt(j['serverNow']),
        participants: (j['participants'] as List?)
                ?.whereType<Map>()
                .map((e) =>
                    PkParticipant.fromJson(Map<String, dynamic>.from(e)))
                .toList() ??
            const [],
        raw: j,
      );
}

/// Backend hata kodları -> Türkçe kullanıcı mesajı.
class PkException implements Exception {
  final String code;
  final String message;
  final int statusCode;

  const PkException(this.code, this.message, this.statusCode);

  String get userMessage {
    switch (code) {
      case 'UNAUTHORIZED':
        return 'Oturumunuz sona ermiş, tekrar giriş yapın';
      case 'NOT_OWNER':
      case 'NOT_STREAM_OWNER':
        return 'PK başlatma yetkiniz yok';
      case 'ROOM_INACTIVE':
      case 'STREAM_NOT_LIVE':
        return 'Yayınınız kapanmış, tekrar başlatın';
      case 'ROOM_NOT_FOUND':
      case 'STREAM_NOT_FOUND':
        return 'Oturum bulunamadı, sayfayı yenileyin';
      case 'TARGET_NOT_FOUND':
      case 'TARGET_INACTIVE':
      case 'TARGET_NOT_LIVE':
        return 'Rakip artık yayında değil';
      case 'PK_EXISTS':
        return 'Zaten aktif bir PK var';
      case 'SELF_PK':
        return 'Kendinizle PK yapamazsınız';
      case 'PK_EXPIRED':
        return 'Davet zaman aşımına uğradı';
      case 'PK_NOT_PENDING':
        return 'Bu davet zaten yanıtlanmış';
      case 'PK_NOT_ACTIVE':
        return 'PK aktif değil';
      case 'PK_NOT_FOUND':
        return 'PK bulunamadı';
      case 'NOT_AUTHORIZED':
        return 'Bu işlem için yetkiniz yok';
      case 'RATE_LIMITED':
        return 'Çok hızlı denediniz, biraz bekleyin';
      case 'MISSING_PARAMS':
      case 'MISSING_BATTLE_ID':
      case 'MISSING_ROOM_ID':
        return 'Eksik bilgi, tekrar deneyin';
      default:
        return message.isEmpty ? 'Bir hata oluştu' : message;
    }
  }

  bool get shouldRefreshState => statusCode == 409;
  bool get shouldLockButton => code == 'RATE_LIMITED';

  @override
  String toString() => 'PkException($statusCode $code): $message';
}
