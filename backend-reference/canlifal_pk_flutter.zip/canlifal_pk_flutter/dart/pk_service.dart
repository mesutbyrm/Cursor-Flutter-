// CanlıFal — PK (Battle) API istemcisi
// Sözleşme: docs/PK_ENTEGRASYON.md
//
// Bağımlılık: package:http  (pubspec.yaml -> http: ^1.2.0)
// Projenizde zaten bir HTTP katmanı (Dio, ApiClient vb.) varsa `_send`
// metodunu o katmana yönlendirin; geri kalan her şey aynı kalabilir.
//
// Tüm metotlar hata durumunda `PkException` fırlatır; kullanıcıya
// gösterilecek Türkçe metin `PkException.userMessage` içindedir.

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'pk_models.dart';

typedef TokenProvider = FutureOr<String?> Function();

class PkService {
  PkService({
    required this.tokenProvider,
    this.baseUrl = 'https://canlifal.com',
    http.Client? client,
    this.timeout = const Duration(seconds: 20),
  }) : _client = client ?? http.Client();

  /// Bearer token sağlayıcı (secure storage / auth repository'den).
  final TokenProvider tokenProvider;

  /// Üretim: https://canlifal.com — geliştirme: http://10.0.2.2:3000
  final String baseUrl;

  final Duration timeout;
  final http.Client _client;

  /// Sunucu ile istemci saati arasındaki fark. Her yanıtta `serverNow`
  /// geldiğinde güncellenir; geri sayımlar bu farkla düzeltilir.
  Duration clockSkew = Duration.zero;

  void dispose() => _client.close();

  // ───────────────────────────── Ortak istek katmanı ─────────────────────────

  Future<Map<String, dynamic>> _send(
    String method,
    String path, {
    Map<String, String>? query,
    Map<String, dynamic>? body,
  }) async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl$path').replace(
      queryParameters: (query == null || query.isEmpty) ? null : query,
    );
    final headers = <String, String>{
      'Accept': 'application/json',
      if (body != null) 'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };

    http.Response res;
    try {
      final req = http.Request(method, uri)..headers.addAll(headers);
      if (body != null) req.body = jsonEncode(body);
      final streamed = await _client.send(req).timeout(timeout);
      res = await http.Response.fromStream(streamed);
    } on TimeoutException {
      throw const PkException('TIMEOUT', 'İstek zaman aşımına uğradı', 0);
    } catch (e) {
      throw PkException('NETWORK_ERROR', e.toString(), 0);
    }

    Map<String, dynamic> json;
    try {
      final decoded = jsonDecode(res.body);
      json = decoded is Map
          ? Map<String, dynamic>.from(decoded)
          : <String, dynamic>{'data': decoded};
    } catch (_) {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        json = <String, dynamic>{};
      } else {
        throw PkException('HTTP_${res.statusCode}', res.body, res.statusCode);
      }
    }

    _absorbServerNow(json);

    final ok = res.statusCode >= 200 &&
        res.statusCode < 300 &&
        json['success'] != false &&
        json['error'] == null;

    if (!ok) {
      throw PkException(
        _errorCode(json, res.statusCode),
        _errorMessage(json),
        res.statusCode,
      );
    }
    return json;
  }

  /// `/api/live/pk` zarflı ({success, data}), diğerleri düz döner.
  /// Her iki şekli de tek tipe indirger.
  Map<String, dynamic> _unwrap(Map<String, dynamic> json) {
    final d = json['data'];
    if (d is Map) return Map<String, dynamic>.from(d);
    return json;
  }

  void _absorbServerNow(Map<String, dynamic> json) {
    final raw = json['serverNow'] ??
        (json['data'] is Map ? (json['data'] as Map)['serverNow'] : null);
    if (raw is String) {
      final t = DateTime.tryParse(raw);
      if (t != null) {
        clockSkew = t.toUtc().difference(DateTime.now().toUtc());
      }
    }
  }

  String _errorCode(Map<String, dynamic> json, int status) {
    final c = json['code'] ?? json['errorCode'];
    if (c is String && c.isNotEmpty) return c;
    final e = json['error'];
    if (e is Map && e['code'] is String) return e['code'] as String;
    if (status == 401) return 'UNAUTHORIZED';
    if (status == 403) return 'FORBIDDEN';
    if (status == 404) return 'NOT_FOUND';
    if (status == 429) return 'RATE_LIMITED';
    return 'HTTP_$status';
  }

  String _errorMessage(Map<String, dynamic> json) {
    final e = json['error'];
    if (e is String && e.isNotEmpty) return e;
    if (e is Map && e['message'] is String) return e['message'] as String;
    final m = json['message'];
    if (m is String && m.isNotEmpty) return m;
    return 'Bilinmeyen hata';
  }

  PkBattle? _battleOrNull(Map<String, dynamic> json) {
    final d = _unwrap(json);
    final candidate = (d['battle'] is Map)
        ? Map<String, dynamic>.from(d['battle'] as Map)
        : (d['pkBattle'] is Map)
            ? Map<String, dynamic>.from(d['pkBattle'] as Map)
            : d;
    if (candidate['id'] == null) return null;
    return PkBattle.fromJson(candidate);
  }

  // ───────────────────────── Birleşik uç: /api/live/pk ───────────────────────

  /// Oda **veya** yayın için tek kaynak-doğruluk sorgusu.
  /// [contextId] oda kimliği, oda slug'ı, yayın kimliği ya da yayının roomId'si
  /// olabilir — backend her ikisini de çözer. Aktif PK yoksa `null` döner.
  Future<PkBattle?> getState(String contextId) async {
    final json = await _send('GET', '/api/live/pk', query: {'roomId': contextId});
    return _battleOrNull(json);
  }

  /// Aktif PK listesi. [isStream] true ise `streamId`, değilse `roomId` gönderilir.
  Future<List<PkBattle>> listActive(
    String contextId, {
    bool isStream = false,
    bool includePending = true,
  }) async {
    final json = await _send('GET', '/api/live/pk/active', query: {
      if (isStream) 'streamId': contextId else 'roomId': contextId,
      if (includePending) 'includePending': '1',
    });
    final d = _unwrap(json);
    final list = (d['battles'] ?? d['items'] ?? d['pkBattles']) as List?;
    return (list ?? const [])
        .whereType<Map>()
        .map((e) => PkBattle.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  /// PK daveti gönderir. [contextId] kendi odanız/yayınınız, [targetId] karşı taraf.
  /// Karışık (oda ↔ yayın) eşleşme desteklenir.
  /// [duration] saniye cinsinden: varsayılan 180, min 60, maks 600.
  Future<PkBattle?> create({
    required String contextId,
    required String targetId,
    int duration = 180,
  }) async {
    final json = await _send('POST', '/api/live/pk', body: {
      'action': 'create',
      'roomId': contextId,
      'targetRoomId': targetId,
      'duration': duration,
    });
    return _battleOrNull(json);
  }

  /// Gelen daveti kabul eder (yalnız davet edilen taraf).
  Future<PkBattle?> accept(String battleId) => _action('accept', battleId);

  /// Gelen daveti reddeder (yalnız davet edilen taraf).
  Future<PkBattle?> reject(String battleId) => _action('reject', battleId);

  /// Gönderilen daveti geri çeker (yalnız gönderen; durum `pending` iken).
  Future<PkBattle?> cancel(String battleId) => _action('cancel', battleId);

  /// Devam eden PK'yı erken bitirir (`active`/`paused` iken).
  Future<PkBattle?> end(String battleId) => _action('end', battleId);

  Future<PkBattle?> _action(String action, String battleId) async {
    final json = await _send('POST', '/api/live/pk', body: {
      'action': action,
      'battleId': battleId,
    });
    return _battleOrNull(json);
  }

  // ───────────────────────────── Aday listeleri ──────────────────────────────

  /// Yayın için PK adayları (canlı olan diğer yayınlar).
  Future<PkCandidateList> getStreamCandidates(String streamId) async {
    final json = await _send('GET', '/api/video-streams/pk/candidates',
        query: {'streamId': streamId});
    return PkCandidateList.fromJson(_unwrap(json));
  }

  /// Sesli oda için PK adayları (aktif olan diğer odalar).
  Future<PkCandidateList> getRoomCandidates(String roomId) async {
    final json = await _send('GET', '/api/chat/rooms/pk/candidates',
        query: {'roomId': roomId});
    return PkCandidateList.fromJson(_unwrap(json));
  }

  // ──────────────────── Sesli odaya özel uçlar (/api/chat/rooms) ─────────────

  /// Oda PK durumu + katılımcı listesi. Oda içi kullanıcı PK'sında katılımcılar
  /// yalnız bu uçtan gelir.
  Future<PkBattle?> getRoomState(String roomId) async {
    final json = await _send('GET', '/api/chat/rooms/$roomId/pk');
    return _battleOrNull(json);
  }

  /// Oda↔oda PK daveti (oda sahibi).
  Future<PkBattle?> createRoomPk({
    required String roomId,
    required String targetRoomId,
    int duration = 180,
  }) async {
    final json = await _send('POST', '/api/chat/rooms/$roomId/pk', body: {
      'action': 'create',
      'targetRoomId': targetRoomId,
      'duration': duration,
    });
    return _battleOrNull(json);
  }

  /// Oda **içi** kullanıcı-vs-kullanıcı PK'sı (oda sahibi/yönetici başlatır).
  /// [side1] ve [side2] koltuktaki kullanıcıların kimlikleri.
  Future<PkBattle?> createUserPk({
    required String roomId,
    required List<String> side1,
    required List<String> side2,
    int duration = 180,
    int countdownSec = 5,
  }) async {
    final json = await _send('POST', '/api/chat/rooms/$roomId/pk', body: {
      'action': 'create_user',
      'side1': side1,
      'side2': side2,
      'duration': duration,
      'countdownSec': countdownSec,
    });
    return _battleOrNull(json);
  }

  /// Geri sayımı bitirip PK'yı başlatır.
  Future<PkBattle?> startRoomPk(String roomId, String battleId) =>
      _roomAction(roomId, 'start', battleId);

  /// PK'yı duraklatır (`active` → `paused`).
  Future<PkBattle?> pauseRoomPk(String roomId, String battleId) =>
      _roomAction(roomId, 'pause', battleId);

  /// Duraklatılmış PK'yı sürdürür (`paused` → `active`).
  Future<PkBattle?> resumeRoomPk(String roomId, String battleId) =>
      _roomAction(roomId, 'resume', battleId);

  /// Oda PK'sını bitirir.
  Future<PkBattle?> endRoomPk(String roomId, String battleId) =>
      _roomAction(roomId, 'end', battleId);

  Future<PkBattle?> _roomAction(
      String roomId, String action, String battleId) async {
    final json = await _send('POST', '/api/chat/rooms/$roomId/pk', body: {
      'action': action,
      'battleId': battleId,
    });
    return _battleOrNull(json);
  }

  // ───────────────────────── Yayına özel uçlar (web ile ortak) ───────────────

  /// Yayın PK durumu. [streamId] yayın kimliği **veya** yayının roomId'si olabilir.
  Future<PkBattle?> getStreamState(String streamId) async {
    final json = await _send('GET', '/api/video-streams/pk',
        query: {'streamId': streamId});
    return _battleOrNull(json);
  }

  /// Yayın↔yayın PK daveti.
  Future<PkBattle?> createStreamPk({
    required String streamId,
    required String targetStreamId,
    int duration = 180,
  }) async {
    final json = await _send('POST', '/api/video-streams/pk', body: {
      'action': 'create',
      'streamId': streamId,
      'targetStreamId': targetStreamId,
      'duration': duration,
    });
    return _battleOrNull(json);
  }

  /// Yayın PK action'ları: accept / reject / cancel / end.
  Future<PkBattle?> streamAction(String action, String battleId) async {
    final json = await _send('POST', '/api/video-streams/pk', body: {
      'action': action,
      'battleId': battleId,
    });
    return _battleOrNull(json);
  }
}
